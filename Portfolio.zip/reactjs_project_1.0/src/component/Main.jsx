import React from "react";
import Navbar from "./navbar/Navbar.jsx";
import Home from "./home/Home.jsx";
import './Main.scss'


const Main = () => {
  return (
    <>
      <div className="_main">
        <div className="_home_container">
          <Navbar />
          <Home />
        </div>
      </div>
    </>
  );
};

export default Main;
