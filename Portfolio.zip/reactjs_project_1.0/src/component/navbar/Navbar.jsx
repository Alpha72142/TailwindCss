import React from "react";
import './Navbar.scss'
import { Menubar } from "primereact/menubar";


const Navbar = () => {
    const items = [
        {
            label: 'Home',
        },
        {
            label: 'About',
        },
        {
            label: 'Projects',
        },
        {
            label: 'Contact',
        }
    ];

    return (
        <div className="_menubar">
            
            <Menubar start={<img className="navbar-brand" alt="" />} model={items} />
        </div>
    )
};

export default Navbar;
