import './App.css';
import Main from './component/Main.jsx';


function App() {
  return (
    <div className="App">
      <Main/>
    </div>
  );
}

export default App;
