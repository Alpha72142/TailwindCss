import React, { useEffect, useRef, useState } from "react";
import "./About.scss";

const About = () => {
  const text = `
    Hello! I'm a passionate designer and developer with a flair for
    full-stack development, specializing in React.js, Node.js, and Java.
    I thrive on the thrill of transforming ideas into stunning digital
    experiences, ensuring every pixel is perfect and every line of code
    is impeccable. My journey into the world of web development began in
    2022, and over the past two years, it has been a rollercoaster of
    excitement and growth. I relish the opportunity to tackle new
    challenges, constantly learning and integrating the latest
    technologies to stay ahead of the curve. As a progressive thinker, I
    love to take projects from the spark of an idea all the way to a
    polished, fully functional product. When I'm not deep in developer
    mode, you can find me diving into k-novels or unleashing my
    creativity through paper crafting. To see some of my front-end
    templates and other projects, follow me on GitHub or Instagram. A
    bit more about me: I hold a B.Tech in Mechatronic Engineering, a
    background that fuels my analytical and creative problem-solving
    skills. I'm always eager to collaborate and bring innovative ideas
    to life. Let's connect and create something extraordinary together!
  `;
  const [isExpanded, setIsExpanded] = useState(false);
  const contentRef = useRef(null);
  const [contentHeight, setContentHeight] = useState("0px");
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    if (contentRef.current) {
      setContentHeight(
        isExpanded ? `${contentRef.current.scrollHeight}px` : "100px"
      );
    }
  }, [isExpanded]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerHeight <= 1444) {
        setIsMobile(true);
      } 
      else {
        setIsMobile(false);
        setIsExpanded(true); // Ensure content is always expanded on larger screens
      }
    };

    handleResize(); // Initial check
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  const toggleContent = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <div className="bg-gradient-to-b from-[#151727] to-[#a9adc5] md:from-[#090a10] md:to-[#a9adc5] border-top-solid">
      <div className="flex-col text-center items-center max-w-sm md:max-w-full p-6  text-white space-x-3 bg-transparent">
        <h4 className="font-bold text-[1.3em] m-auto py-2 px-4 rounded-full bg-slate-600 w-fit">
          About
        </h4>
        <div className="columns md:flex ml-0 mt-12">
          <img
            className="rounded w-[100%] lg:w-[40%] md:w-[40%] md:h-[100%] xl:w-[40%] shadow-sm shadow-white"
            src="/assets/images/samuel2.jpg"
            alt=""
          />
          <div className="columns">
            <h2 className="md:ml-14 lg:ml-32 text-md md:text-justify text-2xl font-bold mt-[1em] md:mt-0 ">
              Curious About Me?
            </h2>
            <p
              ref={contentRef}
              style={{ maxHeight: isMobile ? contentHeight : "none" }}
              className={`md:ml-14 lg:ml-32 text-md text-justify mt-[1em] overflow-hidden transition-max-height duration-500 ease-in-out ${
                isMobile ? "" : "md:max-h-none"
              }`}
            >
              {text}
            </p>
            <div className="flex">
            {isMobile && (
              <button
                onClick={toggleContent}
                className="mt-2 ml-[auto] text-blue-500 focus:outline-none"
              >
                {isExpanded ? "Read Less" : "Read More"}
              </button>
            )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
