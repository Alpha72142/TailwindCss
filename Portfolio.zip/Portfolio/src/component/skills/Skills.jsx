import React from 'react'

const Skills = () => {
    const items = [
        {
            img:"/assets/images/figma.svg",
            label:"Figma",
        },
        {
            img:"/assets/images/reactjs.svg",
            label:"ReactJs",
        },
        {
            img:"/assets/images/angular.svg",
            label:"Angular",
        },
        {
            img:"./assets/images/tailwindcss.svg",
            label:"TailwindCSS",
        },
        {
            img:"/assets/images/js.svg",
            label:"JavaScript",
        },
        {
            img:"/assets/images/ts.svg",
            label:"TypeScript",
        },
        {
            img:"/assets/images/sass.svg",
            label:"Sass/SCSS",
        },
        {
            img:"/assets/images/mdb.svg",
            label:" MongoDB",
        },
        {
            img:"/assets/images/nodejs.svg",
            label:"Node.js",
        },
        {
            img:"/assets/images/java.svg",
            label:"Java",
        },
        {
            img:"/assets/images/git.svg",
            label:"Git",
        }
    ]
  return (
    <div>
        <div className='flex-col text-center items-center p-6  md:max-w-full  text-white bg-gradient-to-b from-[#a9adc5] to-[#ffffff] m-auto'>
            <div>
            <h4 className='font-bold text-[1.3em] m-auto py-2 px-4 rounded-full bg-slate-500 w-fit'>Skills</h4>
            <h5 className='font-medium pt-3 text-gray-800'>Skills, Tools, and Technologies I'm Proficient In</h5>
            <div className='flex flex-wrap pt-4 justify-evenly'>
             {
                items.map((item)=>{
                    return(
                        <div className='flex w-24 flex-col justify-center items-center p-3'>
                               <img className='w-14 h-14 md:w-20 md:h-10' src={item.img} alt="" />
                               <p className='fs-6 mt-2 text-slate-800'>{item.label}</p>
                        </div>
                    )
                })
             }
             </div>
             </div>
        </div>
    </div>
  )
}

export default Skills