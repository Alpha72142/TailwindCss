import React, { useEffect } from 'react'
import './Navbar.scss'

const NavbarUp = () => {
   
    useEffect(() => {
        const btn = document.getElementById('menu-btn');
        const menu = document.getElementById('menu');
        
        const navToggle = () => {
            btn.classList.toggle('open');
            menu.classList.toggle('flex');
            menu.classList.toggle('hidden');
        }

        btn.addEventListener('click', navToggle);

        // Cleanup function
        return () => {
            btn.removeEventListener('click', navToggle);
        }
    }, []);


const navbarItems = [
    {
        id: 1,
        name: "Home",
        path: "section1"
    },
    {
        id: 2,
        name: "About",
        path: "section2"
    },
    {
        id: 3,
        name: "Skills",
        path: "section3"
    },
    {
        id: 4,
        name: "Experience",
        path: "section4"
    },
    {
        id: 5,
        name: "Projects",
        path: "section5"
    },
    {
        id: 5,
        name: "Contact",
        path: "section6"
    }
]

const handleScroll = (id) => {
    const element = document.getElementById(id);
    if(element){
        element.scrollIntoView({ behavior: 'smooth' });
    }
   
}

  return (
    <>
    <nav style={{zIndex: '9999'}} className='flex md:sticky relative md:top-0 pt-3 px-6 md:p-0 items-center justify-between font-bold text-white _menubar '>
        {/* logo */}
        <img src='/assets/images/S_logo.png' className="max-w-[4em] mb-[1.6%] md:ml-[2em]" alt="" />
        {/* menu */}
        <div className="hidden px-4 h-10 font-Alata md:flex md:space-x-8">
            {navbarItems.map((item) => (
                <div className="group" key={item.id}>
                <span onClick={() => handleScroll(item.path)} className='cursor-pointer'>{item.name}</span>
                <div className="mx-2 group-hover:border opacity-0 group-hover:opacity-100 rounded transition-all duration-500 group-hover:border-blue-50"></div>
            </div>
            ))}
        </div>
        {/* Hamburger button */}
        <div className="md:hidden">
            <button id='menu-btn' type='button' className="z-40 block hamburger md:hidden focus:outline-none">
                <span className='hamburger-top'></span>
                <span className='hamburger-middle'></span>
                <span className='hamburger-bottom'></span>
            </button>
        </div>
    </nav>
     {/*Mobile Menu*/}
     <div id="menu" className="absolute top-0 bottom-0 left-0 hidden flex-col self-end  w-full min-h-screen py-6 pt-40 pl-12 space-y-3 text-lg text-white uppercase bg-black z-1">
        {navbarItems.map((item) => (
            <span onClick={() => handleScroll(item.path)} className="hover:text-pink-500 cursor-pointer">{item.name}</span>
        ))}
        
     </div>
    </>
  )
}

export default NavbarUp