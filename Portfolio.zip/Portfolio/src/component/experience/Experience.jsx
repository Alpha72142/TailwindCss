import React from 'react'

const Experience = () => {
  return (
    <div className='flex flex-column text-center items-center bg-[#ffffff]'>
        <h4 className='font-bold text-[1.3em] m-auto py-2 px-4 rounded-full bg-slate-500 w-fit text-white'>Experiences</h4>
        <h4 class="font-medium pt-3 text-gray-800">Quick Summary of My Recent Experiences</h4>
        <div class="bg-white shadow-lg rounded-lg overflow-hidden w-3/4 mt-4">
        <div class="flex flex-col md:flex-row">
            <div class="md:w-1/4 order-1 !p-4 bg-blue-100">
                <img src="/assets/images/logo-transparent-svg.svg " className='' alt="" />
            </div>
            <div class="flex flex-col md:w-1/2  md:!order-2 order-3 p-4 bg-green-100">
                <h4 className='font-bold text-lg mr-auto'>full Stack developer</h4>
                <ul>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>


            </div>
            <div class="md:w-1/4 md:!order-3 order-2 p-4 bg-red-100">
                <p className='font-medium'>june 2022- Sept 2023</p>
            </div>
        </div>
    </div>
    </div>
  )
}

export default Experience