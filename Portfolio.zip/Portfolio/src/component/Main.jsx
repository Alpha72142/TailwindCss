import React from "react";

import Home from "./home/Home.jsx";
import "./Main.scss";
import About from "./about/About.jsx";
import NavbarUp from "./navbar/NavbarUp.jsx";
import Skills from "./skills/Skills.jsx";
import Experience from "./experience/Experience.jsx";

const Main = () => {
  return (
    <>
      <div className="_main">
        <div className="_home_container">
          <div className="_userImage md:hidden"></div>
          <NavbarUp />
          <section id="section1">
            <Home />
          </section>
        </div>
        <div className="about">
          <section id="section2">
            <About />
          </section>
          <section id="section3">
            <Skills />
          </section>
          <section id="section4">
            <Experience />
          </section>
        </div>
      </div>
    </>
  );
};

export default Main;
