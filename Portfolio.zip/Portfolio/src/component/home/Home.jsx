import React from "react";
import "./Home.scss";

const Home = () => {
  const brand = "/assets/images/S2.png";

  const Modal = () => {
    return (
      <>
        <div
          class="modal fade"
          id="staticBackdrop"
          data-bs-backdrop="false"
          data-bs-keyboard="false"
          tabindex="-1"
          aria-labelledby="staticBackdropLabel"
          aria-hidden="true"
        >
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <i
                  type="button"
                  class="bi-x"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></i>
              </div>
              <div class="modal-body">
                Hello, I am Samuel - a Front-end developer from India, who loves
                crafting user-friendly websites and applications.
              </div>
            </div>
          </div>
        </div>
      </>
    );
  };

  return (
    <div className="_home row">
      <div className="image"></div>
      <div className="text_container col-md-4 col-sm-4 md:m-0 mt-3  ">
        <div className="overlay "></div>
        <div className="ms-5">
          <span className="first_text text-white ">
            Hi,
            <i
              class="bi bi-info-circle-fill ms-auto d-none"
              data-bs-toggle="modal"
              data-bs-target="#staticBackdrop"
            ></i>
          </span>
          <Modal />
          <br />
          <span className="sec_text text-white">Welcome to</span>
        </div>
        <div className=" _note_container ms-5 mb-5 mt-auto w-75">
          <p className="note_text p-4 fw-bolder text-center">
            Hello, I am Samuel - a Front-end developer from India, who loves
            crafting user-friendly websites and applications.
            <br />
            Welcome to my Matrix.
          </p>
        </div>
      </div>
      <div className="col-md-4 col-sm-4 d-flex justify-content-center align-items-center">
        <img className="home-brand w-100" src={brand} alt="" />
      </div>
      <div className="text_container col-md-4 col-sm-4 d-flex flex-column">
        <span className="third_text ms-auto me-5 mb-4 text-white mt-auto">
          Website
        </span>
      </div>
    </div>
  );
};

export default Home;
