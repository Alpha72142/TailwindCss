
import "./App.css";
import EmailSubscribeCard from "./Component/email_subscribe_card/EmailSubscribeCard";
import { ImageGallery } from "./Component/image_gallary/ImageGallery";
import LoginModal from "./Component/login_modal/LoginModal";
import PricingGrid from "./Component/pricing_grid_cards/PricingGridCards";
import ProductModal from "./Component/product_modal/ProductModal";

function App() {
  return (
    <div className="App">
      <EmailSubscribeCard/>
      <PricingGrid/>
      <ProductModal/>
      <ImageGallery/>
      <LoginModal/>

    </div>
  );
}

export default App;
