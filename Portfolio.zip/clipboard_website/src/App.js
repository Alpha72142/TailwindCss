import logo from './logo.svg';
import './App.css';
import Master from './component/Master';




function App() {
  return (
      <div className="App">
        <Master/>
      </div>
  );
}

export default App;
