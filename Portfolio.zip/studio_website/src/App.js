import MainSection from './component/MainSection';

function App() {
  return (
    <div className="App">
      <MainSection/>
    </div>
  );
}

export default App;
